# Froth & Fable
A whimsical coffee & book shop website hosted on GitHub Pages.